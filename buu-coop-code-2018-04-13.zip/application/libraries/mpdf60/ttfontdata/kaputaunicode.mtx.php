<?php
$name='KaputaUnicode';
$type='TTF';
$desc=array (
  'CapHeight' => 571,
  'XHeight' => 423,
  'FontBBox' => '[-514 -287 1293 747]',
  'Flags' => 4,
  'Ascent' => 746,
  'Descent' => -254,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 430,
);
$unitsPerEm=2048;
$up=-37;
$ut=24;
$strp=250;
$strs=50;
$ttffile='C:/xampp/htdocs/mpdf60/ttfonts/kaputaunicode.ttf';
$TTCfontID='0';
$originalsize=159696;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='kaputaunicode';
$panose=' 0 0 1 1 1 0 1 1 1 1 1 1';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 746, -254, 36
// usWinAscent/usWinDescent = 746, -254
// hhea Ascent/Descent/LineGap = 746, -254, 36
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'sinh' => 'DFLT ',
);
$GSUBFeatures=array (
  'sinh' => 
  array (
    'DFLT' => 
    array (
      'rphf' => 
      array (
        0 => 0,
        1 => 4,
        2 => 5,
        3 => 8,
        4 => 9,
      ),
      'pstf' => 
      array (
        0 => 1,
      ),
      'psts' => 
      array (
        0 => 2,
      ),
      'akhn' => 
      array (
        0 => 3,
      ),
      'abvs' => 
      array (
        0 => 6,
      ),
      'blws' => 
      array (
        0 => 7,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157220,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157250,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157280,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157488,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157520,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157550,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 157580,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 158304,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 158530,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 158622,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'sinh' => 'DFLT ',
);
$GPOSFeatures=array (
  'sinh' => 
  array (
    'DFLT' => 
    array (
      'abvm' => 
      array (
        0 => 0,
      ),
      'blwm' => 
      array (
        0 => 1,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 158808,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 158868,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>