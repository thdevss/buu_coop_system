<?php
$name='Lohit-Kannada';
$type='TTF';
$desc=array (
  'CapHeight' => 879,
  'XHeight' => 0,
  'FontBBox' => '[-1032 -686 2387 976]',
  'Flags' => 4,
  'Ascent' => 879,
  'Descent' => -684,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 781,
);
$unitsPerEm=1024;
$up=-303;
$ut=20;
$strp=244;
$strs=49;
$ttffile='C:/xampp/htdocs/mpdf60/ttfonts/Lohit-Kannada.ttf';
$TTCfontID='0';
$originalsize=197872;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='lohitkannada';
$panose=' 0 0 2 b 6 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=true;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 879, -684, 195
// usWinAscent/usWinDescent = 879, -684
// hhea Ascent/Descent/LineGap = 879, -684, 195
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'DFLT' => 'DFLT ',
  'deva' => 'DFLT ',
  'knda' => 'DFLT ',
  'latn' => 'DFLT ',
);
$GSUBFeatures=array (
  'DFLT' => 
  array (
    'DFLT' => 
    array (
      'abvs' => 
      array (
        0 => 1,
      ),
      'psts' => 
      array (
        0 => 2,
        1 => 17,
      ),
    ),
  ),
  'deva' => 
  array (
    'DFLT' => 
    array (
      'abvs' => 
      array (
        0 => 1,
      ),
      'psts' => 
      array (
        0 => 2,
        1 => 17,
      ),
    ),
  ),
  'knda' => 
  array (
    'DFLT' => 
    array (
      'abvs' => 
      array (
        0 => 1,
        1 => 3,
      ),
      'psts' => 
      array (
        0 => 2,
        1 => 16,
        2 => 17,
      ),
      'akhn' => 
      array (
        0 => 4,
      ),
      'blwf' => 
      array (
        0 => 5,
      ),
      'blws' => 
      array (
        0 => 6,
        1 => 7,
        2 => 8,
        3 => 9,
        4 => 10,
        5 => 11,
        6 => 12,
        7 => 13,
      ),
      'haln' => 
      array (
        0 => 14,
      ),
      'pstf' => 
      array (
        0 => 15,
      ),
      'rphf' => 
      array (
        0 => 18,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'abvs' => 
      array (
        0 => 1,
      ),
      'psts' => 
      array (
        0 => 2,
        1 => 17,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 190446,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 190542,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 5,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 190616,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 190644,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 192760,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 193520,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194236,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194266,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194296,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194326,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194356,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194386,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194416,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194446,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 194586,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 195022,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 195664,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 3,
    'Subtables' => 
    array (
      0 => 195820,
      1 => 195982,
      2 => 196192,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196252,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196276,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196288,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196300,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196318,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196340,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'DFLT' => 'DFLT ',
  'deva' => 'DFLT ',
  'knda' => 'DFLT ',
  'latn' => 'DFLT ',
);
$GPOSFeatures=array (
  'DFLT' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 3,
        2 => 4,
      ),
      'blwm' => 
      array (
        0 => 1,
      ),
    ),
  ),
  'deva' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 3,
        2 => 4,
      ),
      'blwm' => 
      array (
        0 => 1,
      ),
    ),
  ),
  'knda' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 2,
        2 => 3,
        3 => 4,
      ),
      'blwm' => 
      array (
        0 => 1,
      ),
    ),
  ),
  'latn' => 
  array (
    'DFLT' => 
    array (
      'kern' => 
      array (
        0 => 0,
        1 => 3,
        2 => 4,
      ),
      'blwm' => 
      array (
        0 => 1,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196556,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 196656,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 197516,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 197540,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 197818,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>