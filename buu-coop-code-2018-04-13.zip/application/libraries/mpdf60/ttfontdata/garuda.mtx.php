<?php
$name='Garuda';
$type='TTF';
$desc=array (
  'CapHeight' => 716,
  'XHeight' => 518,
  'FontBBox' => '[-659 -589 1090 1288]',
  'Flags' => 4,
  'Ascent' => 1284,
  'Descent' => -589,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 766,
);
$unitsPerEm=1000;
$up=-32;
$ut=10;
$strp=258;
$strs=49;
$ttffile='C:/xampp/htdocs/mpdf60/ttfonts/Garuda.ttf';
$TTCfontID='0';
$originalsize=57324;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='garuda';
$panose=' 0 0 2 b 6 4 2 2 2 2 2 4';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 840, -160, 0
// usWinAscent/usWinDescent = 1284, -591
// hhea Ascent/Descent/LineGap = 1284, -591, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'thai' => 'DFLT KUY  PAL  THA  ',
);
$GSUBFeatures=array (
  'thai' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
    'KUY ' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
    'PAL ' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
      ' RQD' => 
      array (
        0 => 2,
      ),
    ),
    'THA ' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 55544,
      1 => 55952,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56140,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 5,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56176,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56204,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56222,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56242,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56298,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56310,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56326,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56344,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56362,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56380,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56398,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56416,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56434,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56452,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56470,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56488,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56506,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56524,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56542,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56560,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56578,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56596,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56614,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56632,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56650,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56668,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'thai' => 'DFLT KUY  PAL  THA  ',
);
$GPOSFeatures=array (
  'thai' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
    'KUY ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
    'PAL ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
    'THA ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56798,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56878,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57128,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>