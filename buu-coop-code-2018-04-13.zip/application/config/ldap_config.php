<?php
//$config['notification_on']="on";
//$config['ldap_on']="on";
$config['host'] = "10.4.1.82";
$config['port'] = "389";//ldaps 689
$config['account_prefix'] = "BUU\\";
$config['base_dn'] ="OU=People,DC=BUU,DC=AC,DC=TH";

?>