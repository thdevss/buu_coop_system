<?php
$lang['form_validation_required'] = '{field}, โปรดกรอกข้อมูลในช่อง';
$lang['form_validation_numeric'] = '{field}, โปรดกรอกเฉพาะตัวเลข';
$lang['form_validation_valid_email'] = '{field}, โปรดกรอกอีเมลให้ถูกต้อง';
$lang['form_validation_valid_email'] = '{field}, โปรดกรอกอีเมลให้ถูกต้อง';

